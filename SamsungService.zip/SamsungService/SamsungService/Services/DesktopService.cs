﻿//using SamsungService.Models;
//using SamsungService.Repositories;

//namespace SamsungService.Services
//{
//    public class DesktopService :IDesktopService
//    {
//        private readonly IDesktopRepository _desktopRepository;

//        public DesktopService(IDesktopRepository desktopRepository)
//        {
//            _desktopRepository = desktopRepository;
//        }

//        //public Desktop GetDesktopById(int desktopId)
//        //{
//        //    return _desktopRepository.GetDesktopById(desktopId);
//        //}

//        public List<Desktop> GetAllDesktops()
//        {
//            return _desktopRepository.GetAllDesktops();
//        }

//        //public List<Desktop> SearchDesktops(string searchText)
//        //{
//        //    return _desktopRepository.SearchDesktops(searchText);
//        //}

//        //public void AddDesktop(Desktop desktop)
//        //{
//        //    _desktopRepository.GetAllDesktops(desktop);
//        //}

//        //public void UpdateDesktop(Desktop existingDesktop, Desktop updatedDesktop)
//        //{
//        //    existingDesktop.SmartDisk = updatedDesktop.SmartDisk;
//        //    existingDesktop.DiskSpace = updatedDesktop.DiskSpace;
//        //    existingDesktop.SecurityUpdates = updatedDesktop.SecurityUpdates;
//        //    existingDesktop.Sitecode = updatedDesktop.Sitecode;
//        //    existingDesktop.Antivirus = updatedDesktop.DiskSpace;
//        //    existingDesktop.Alive = updatedDesktop.Alive;
//        //    existingDesktop.Amt= updatedDesktop.Amt;

//        //    _desktopRepository.UpdateDesktop(existingDesktop);
//        //}

//        //public void DeleteDesktop(Desktop desktop)
//        //{
//        //    _desktopRepository.UpdateDesktop(existingDesktop);
//        //}

  
//    }
//}
