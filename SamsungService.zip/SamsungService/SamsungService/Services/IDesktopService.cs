﻿//using SamsungService.Models;

//namespace SamsungService.Services
//{
//    public interface IDesktopService
//    {
//        //Desktop GetDesktopById(int desktopId);
//        List<Desktop> GetAllDesktops();
//        //List<Desktop> SearchDesktops(string searchText);
//        //void AddDesktop(Desktop desktop);
//        //void UpdateDesktop(Desktop desktop);
//        //void DeleteDesktop(Desktop desktop);
//    }
//}
