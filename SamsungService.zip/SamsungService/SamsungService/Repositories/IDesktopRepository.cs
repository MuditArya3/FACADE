﻿//using SamsungService.Models;

//namespace SamsungService.Repositories
//{
//    public interface IDesktopRepository
//    {
//        //Desktop GetDesktopById(int desktopId);
//        List<Desktop> GetAllDesktops();
//        //List<Desktop> SearchDesktops(string searchText);
//        //void AddDesktop(Desktop desktop);
//        //void UpdateDesktop(Desktop desktop);
//        //void DeleteDesktop(Desktop desktop);
//    }
//}
